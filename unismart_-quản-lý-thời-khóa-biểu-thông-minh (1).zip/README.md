# UniSmart: Quản lý Thời khóa biểu Thông minh

UniSmart là một ứng dụng web giúp sinh viên (đặc biệt là sinh viên năm nhất) quản lý thời khóa biểu, nhiệm vụ học tập và nhận tư vấn từ trợ lý AI thông minh.

## Tính năng chính

- **Thời khóa biểu trực quan**: Quản lý lịch học theo tuần với giao diện kéo thả (sắp tới) và mã màu.
- **Quản lý nhiệm vụ**: Theo dõi bài tập, deadline gắn liền với từng môn học.
- **Trợ lý AI (Gemini)**: Tư vấn lộ trình học tập, giải đáp thắc mắc và tối ưu hóa thời gian biểu.
- **Lưu trữ cục bộ**: Dữ liệu được lưu an toàn trên trình duyệt của bạn.

## Công nghệ sử dụng

- **Frontend**: React 19, TypeScript, Vite
- **Styling**: Tailwind CSS 4
- **Animation**: Motion (Framer Motion)
- **AI**: Google Gemini API (@google/genai)
- **Icons**: Lucide React

## Cài đặt và Chạy thử

1. **Clone repository**:
   ```bash
   git clone <your-repo-url>
   cd unismart
   ```

2. **Cài đặt dependencies**:
   ```bash
   npm install
   ```

3. **Cấu hình biến môi trường**:
   Tạo file `.env` từ `.env.example` và thêm `GEMINI_API_KEY` của bạn.
   ```bash
   cp .env.example .env
   ```

4. **Chạy ở chế độ development**:
   ```bash
   npm run dev
   ```

5. **Build cho production**:
   ```bash
   npm run build
   ```

## Giấy phép

Dự án này được phát hành dưới giấy phép Apache-2.0.
