import React, { useState } from 'react';
import { Task, ClassSession } from '../types';
import { Plus, CheckCircle2, Circle, Clock, Trash2, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';

interface TaskBoardProps {
  tasks: Task[];
  classes: ClassSession[];
  onAddTask: (task: Task) => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

export default function TaskBoard({ tasks, classes, onAddTask, onToggleTask, onDeleteTask }: TaskBoardProps) {
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [selectedClassId, setSelectedClassId] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    onAddTask({
      id: Math.random().toString(36).substr(2, 9),
      title: newTaskTitle,
      completed: false,
      dueDate: new Date().toISOString(),
      priority: 'medium',
      classId: selectedClassId || undefined,
    });
    setNewTaskTitle('');
    setSelectedClassId('');
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
      <div className="p-6 border-b border-slate-100">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Nhiệm vụ & Bài tập</h2>
        
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex gap-2">
            <input
              type="text"
              value={newTaskTitle}
              onChange={e => setNewTaskTitle(e.target.value)}
              placeholder="Thêm nhiệm vụ mới..."
              className="flex-1 px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
            <button
              type="submit"
              className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-lg shadow-blue-100"
            >
              <Plus size={24} />
            </button>
          </div>
          
          <select
            value={selectedClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="w-full px-4 py-1.5 text-sm rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all bg-slate-50"
          >
            <option value="">Gắn với môn học (tùy chọn)</option>
            {classes.map(cls => (
              <option key={cls.id} value={cls.id}>{cls.name}</option>
            ))}
          </select>
        </form>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {sortedTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-400 space-y-2 py-10">
            <CheckCircle2 size={48} strokeWidth={1} />
            <p>Chưa có nhiệm vụ nào!</p>
          </div>
        ) : (
          sortedTasks.map(task => {
            const relatedClass = classes.find(c => c.id === task.classId);
            return (
              <div
                key={task.id}
                className={cn(
                  "group flex items-start gap-3 p-3 rounded-xl border transition-all",
                  task.completed ? "bg-slate-50 border-slate-100 opacity-60" : "bg-white border-slate-200 hover:border-blue-300 hover:shadow-md"
                )}
              >
                <button
                  onClick={() => onToggleTask(task.id)}
                  className={cn(
                    "mt-0.5 transition-colors",
                    task.completed ? "text-emerald-500" : "text-slate-300 hover:text-blue-500"
                  )}
                >
                  {task.completed ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                </button>

                <div className="flex-1 min-w-0">
                  <p className={cn(
                    "font-medium text-slate-800 truncate",
                    task.completed && "line-through text-slate-400"
                  )}>
                    {task.title}
                  </p>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
                    {relatedClass && (
                      <span className={cn(
                        "text-[10px] px-2 py-0.5 rounded-full font-medium",
                        relatedClass.color || "bg-blue-50 text-blue-600"
                      )}>
                        {relatedClass.name}
                      </span>
                    )}
                    <div className="flex items-center gap-1 text-[10px] text-slate-400">
                      <Clock size={12} />
                      <span>{format(new Date(task.dueDate), 'dd/MM', { locale: vi })}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteTask(task.id)}
                  className="p-1 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
