import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage, ClassSession, Task } from '../types';
import { Send, Bot, User, Sparkles, Loader2, RotateCcw } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cn } from '../lib/utils';

interface AIAssistantProps {
  classes: ClassSession[];
  tasks: Task[];
}

export default function AIAssistant({ classes, tasks }: AIAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', content: 'Chào bạn! Mình là trợ lý UniSmart. Mình có thể giúp bạn tối ưu thời khóa biểu, gợi ý cách học hiệu quả hoặc trả lời các thắc mắc về đời sống sinh viên. Bạn cần giúp gì hôm nay?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const context = `
        Dưới đây là thông tin hiện tại của sinh viên:
        Thời khóa biểu: ${JSON.stringify(classes.map(c => ({ name: c.name, day: c.dayOfWeek, time: `${c.startTime}-${c.endTime}` })))}
        Nhiệm vụ: ${JSON.stringify(tasks.map(t => ({ title: t.title, completed: t.completed, class: classes.find(c => c.id === t.classId)?.name })))}
        
        Hãy đóng vai một người cố vấn học tập thông minh cho sinh viên năm nhất. 
        Trả lời bằng tiếng Việt, thân thiện, hữu ích. 
        Nếu sinh viên hỏi về lịch trình, hãy phân tích xem họ có đang quá tải không hoặc gợi ý thời gian tự học.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: 'user', parts: [{ text: context }] },
          ...messages.map(m => ({ role: m.role, parts: [{ text: m.content }] })),
          { role: 'user', parts: [{ text: userMsg }] }
        ],
        config: {
          temperature: 0.7,
          topP: 0.8,
          topK: 40,
        }
      });

      const aiResponse = response.text || "Xin lỗi, mình gặp chút trục trặc khi suy nghĩ. Bạn thử lại nhé!";
      setMessages(prev => [...prev, { role: 'model', content: aiResponse }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'model', content: "Có lỗi xảy ra khi kết nối với trí tuệ nhân tạo. Vui lòng kiểm tra lại kết nối mạng hoặc API key." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <Bot size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-800">Trợ lý AI UniSmart</h2>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">Đang trực tuyến</span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => setMessages([messages[0]])}
          className="p-2 hover:bg-white/50 rounded-full transition-colors text-slate-400"
          title="Xóa hội thoại"
        >
          <RotateCcw size={16} />
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/30">
        {messages.map((msg, i) => (
          <div key={i} className={cn(
            "flex gap-3 max-w-[85%]",
            msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
          )}>
            <div className={cn(
              "w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center",
              msg.role === 'user' ? "bg-slate-200 text-slate-600" : "bg-blue-100 text-blue-600"
            )}>
              {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
            </div>
            <div className={cn(
              "p-3 rounded-2xl text-sm shadow-sm",
              msg.role === 'user' ? "bg-blue-600 text-white rounded-tr-none" : "bg-white border border-slate-100 text-slate-700 rounded-tl-none"
            )}>
              <div className="prose prose-sm prose-slate max-w-none prose-p:leading-relaxed">
                <ReactMarkdown>
                  {msg.content}
                </ReactMarkdown>
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
              <Loader2 size={16} className="animate-spin" />
            </div>
            <div className="bg-white border border-slate-100 p-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
              <span className="text-xs text-slate-400 italic">UniSmart đang suy nghĩ...</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-100 bg-white">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="Hỏi AI về lịch học hoặc mẹo sinh viên..."
            className="w-full pl-4 pr-12 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all shadow-inner bg-slate-50"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 transition-all shadow-lg shadow-blue-100"
          >
            <Send size={18} />
          </button>
        </div>
        <p className="text-[10px] text-center text-slate-400 mt-2 flex items-center justify-center gap-1">
          <Sparkles size={10} /> AI có thể đưa ra thông tin không chính xác. Hãy kiểm tra lại lịch học chính thức.
        </p>
      </div>
    </div>
  );
}
