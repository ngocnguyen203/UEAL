import React from 'react';
import { ClassSession } from '../types';
import { cn } from '../lib/utils';
import { Clock, MapPin } from 'lucide-react';

interface CalendarProps {
  classes: ClassSession[];
  onEditClass: (cls: ClassSession) => void;
}

const DAYS = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ Nhật'];
const HOURS = Array.from({ length: 15 }, (_, i) => i + 7); // 7:00 to 21:00

export default function Calendar({ classes, onEditClass }: CalendarProps) {
  const getClassesForDay = (dayIndex: number) => {
    // dayIndex 0-6 corresponds to Mon-Sun
    // In our type, dayOfWeek 1 is Mon, 0 is Sun? Let's normalize:
    // 1: Mon, 2: Tue, ..., 6: Sat, 0: Sun
    return classes.filter(c => c.dayOfWeek === (dayIndex + 1) % 7);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
      <div className="grid grid-cols-[80px_repeat(7,1fr)] border-b border-slate-200 bg-slate-50/50">
        <div className="p-4 border-r border-slate-200"></div>
        {DAYS.map((day, i) => (
          <div key={day} className="p-4 text-center font-medium text-slate-600 border-r border-slate-200 last:border-r-0">
            {day}
          </div>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto relative">
        <div className="grid grid-cols-[80px_repeat(7,1fr)] min-h-[900px]">
          {/* Time column */}
          <div className="bg-slate-50/30 border-r border-slate-200">
            {HOURS.map(hour => (
              <div key={hour} className="h-20 border-b border-slate-100 p-2 text-xs text-slate-400 font-mono text-right pr-3">
                {hour}:00
              </div>
            ))}
          </div>

          {/* Day columns */}
          {DAYS.map((_, dayIdx) => (
            <div key={dayIdx} className="relative border-r border-slate-100 last:border-r-0 group">
              {/* Grid lines */}
              {HOURS.map(hour => (
                <div key={hour} className="h-20 border-b border-slate-100" />
              ))}

              {/* Classes */}
              {getClassesForDay(dayIdx).map(cls => {
                const [startH, startM] = cls.startTime.split(':').map(Number);
                const [endH, endM] = cls.endTime.split(':').map(Number);
                
                const top = (startH - 7) * 80 + (startM / 60) * 80;
                const height = ((endH - startH) * 60 + (endM - startM)) * (80 / 60);

                return (
                  <button
                    key={cls.id}
                    onClick={() => onEditClass(cls)}
                    className={cn(
                      "absolute left-1 right-1 rounded-lg p-2 text-left text-xs transition-all hover:scale-[1.02] hover:z-10 shadow-sm border overflow-hidden",
                      cls.color || "bg-blue-50 border-blue-200 text-blue-700"
                    )}
                    style={{ top: `${top}px`, height: `${height}px` }}
                  >
                    <div className="font-bold truncate">{cls.name}</div>
                    <div className="flex items-center gap-1 opacity-80 mt-0.5">
                      <MapPin size={10} />
                      <span className="truncate">{cls.room}</span>
                    </div>
                    {height > 60 && (
                      <div className="flex items-center gap-1 opacity-80 mt-0.5">
                        <Clock size={10} />
                        <span>{cls.startTime} - {cls.endTime}</span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
