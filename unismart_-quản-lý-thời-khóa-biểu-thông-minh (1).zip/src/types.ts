export interface ClassSession {
  id: string;
  name: string;
  room: string;
  instructor: string;
  dayOfWeek: number; // 0 (Sun) to 6 (Sat)
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  color: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate: string;
  completed: boolean;
  classId?: string;
  priority: 'low' | 'medium' | 'high';
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
