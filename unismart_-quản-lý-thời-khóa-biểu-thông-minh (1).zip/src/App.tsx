import React, { useState, useEffect } from 'react';
import { ClassSession, Task } from './types';
import Calendar from './components/Calendar';
import ClassForm from './components/ClassForm';
import TaskBoard from './components/TaskBoard';
import AIAssistant from './components/AIAssistant';
import { Plus, Calendar as CalendarIcon, ListTodo, BrainCircuit, GraduationCap, Settings, Bell } from 'lucide-react';
import { cn } from './lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [classes, setClasses] = useState<ClassSession[]>(() => {
    const saved = localStorage.getItem('unismart_classes');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('unismart_tasks');
    return saved ? JSON.parse(saved) : [];
  });

  const [activeTab, setActiveTab] = useState<'calendar' | 'tasks' | 'ai'>('calendar');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassSession | null>(null);

  useEffect(() => {
    localStorage.setItem('unismart_classes', JSON.stringify(classes));
  }, [classes]);

  useEffect(() => {
    localStorage.setItem('unismart_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const handleSaveClass = (cls: ClassSession) => {
    if (editingClass) {
      setClasses(prev => prev.map(c => c.id === cls.id ? cls : c));
    } else {
      setClasses(prev => [...prev, cls]);
    }
    setIsFormOpen(false);
    setEditingClass(null);
  };

  const handleDeleteClass = (id: string) => {
    setClasses(prev => prev.filter(c => c.id !== id));
    setTasks(prev => prev.map(t => t.classId === id ? { ...t, classId: undefined } : t));
    setIsFormOpen(false);
    setEditingClass(null);
  };

  const handleAddTask = (task: Task) => {
    setTasks(prev => [...prev, task]);
  };

  const handleToggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const handleDeleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <GraduationCap size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-800">UniSmart</h1>
            <p className="text-xs text-slate-500 font-medium">Cố vấn học tập 4.0</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all relative">
            <Bell size={20} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
          </button>
          <div className="h-8 w-px bg-slate-200 mx-1" />
          <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
            <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-[10px] text-white font-bold">SV</div>
            <span className="text-sm font-medium text-slate-700">Tân sinh viên</span>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:flex-row h-[calc(100vh-73px)] overflow-hidden">
        {/* Sidebar Navigation */}
        <nav className="bg-white border-r border-slate-200 w-full lg:w-20 flex lg:flex-col items-center justify-around lg:justify-start lg:py-8 gap-4 p-4 lg:p-0 order-last lg:order-first">
          <NavButton 
            active={activeTab === 'calendar'} 
            onClick={() => setActiveTab('calendar')} 
            icon={<CalendarIcon size={24} />} 
            label="Lịch học"
          />
          <NavButton 
            active={activeTab === 'tasks'} 
            onClick={() => setActiveTab('tasks')} 
            icon={<ListTodo size={24} />} 
            label="Nhiệm vụ"
          />
          <NavButton 
            active={activeTab === 'ai'} 
            onClick={() => setActiveTab('ai')} 
            icon={<BrainCircuit size={24} />} 
            label="Trợ lý AI"
          />
          <div className="hidden lg:block flex-1" />
          <NavButton 
            active={false} 
            onClick={() => {}} 
            icon={<Settings size={24} />} 
            label="Cài đặt"
          />
        </nav>

        {/* Content Area */}
        <div className="flex-1 flex flex-col p-4 lg:p-6 gap-6 overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">
                {activeTab === 'calendar' && 'Thời khóa biểu tuần'}
                {activeTab === 'tasks' && 'Danh sách nhiệm vụ'}
                {activeTab === 'ai' && 'Trợ lý học tập AI'}
              </h2>
              <p className="text-slate-500 text-sm">
                {activeTab === 'calendar' && 'Quản lý lịch học và phòng học của bạn'}
                {activeTab === 'tasks' && 'Theo dõi bài tập và các deadline quan trọng'}
                {activeTab === 'ai' && 'Nhận lời khuyên và giải đáp thắc mắc từ AI'}
              </p>
            </div>
            
            {activeTab === 'calendar' && (
              <button
                onClick={() => {
                  setEditingClass(null);
                  setIsFormOpen(true);
                }}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2.5 rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
              >
                <Plus size={20} />
                <span className="hidden sm:inline">Thêm môn học</span>
              </button>
            )}
          </div>

          <div className="flex-1 relative min-h-0">
            <AnimatePresence mode="wait">
              {activeTab === 'calendar' && (
                <motion.div
                  key="calendar"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="h-full"
                >
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
                    <div className="lg:col-span-3 h-full overflow-hidden">
                      <Calendar 
                        classes={classes} 
                        onEditClass={(cls) => {
                          setEditingClass(cls);
                          setIsFormOpen(true);
                        }} 
                      />
                    </div>
                    <div className="hidden lg:block h-full overflow-hidden">
                      <TaskBoard 
                        tasks={tasks} 
                        classes={classes} 
                        onAddTask={handleAddTask}
                        onToggleTask={handleToggleTask}
                        onDeleteTask={handleDeleteTask}
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'tasks' && (
                <motion.div
                  key="tasks"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="h-full max-w-2xl mx-auto w-full"
                >
                  <TaskBoard 
                    tasks={tasks} 
                    classes={classes} 
                    onAddTask={handleAddTask}
                    onToggleTask={handleToggleTask}
                    onDeleteTask={handleDeleteTask}
                  />
                </motion.div>
              )}

              {activeTab === 'ai' && (
                <motion.div
                  key="ai"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="h-full max-w-4xl mx-auto w-full"
                >
                  <AIAssistant classes={classes} tasks={tasks} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Modals */}
      {isFormOpen && (
        <ClassForm 
          initialData={editingClass}
          onSave={handleSaveClass}
          onDelete={handleDeleteClass}
          onClose={() => {
            setIsFormOpen(false);
            setEditingClass(null);
          }}
        />
      )}

      {/* Mobile Quick Action (Floating) */}
      {activeTab === 'calendar' && (
        <button
          onClick={() => {
            setEditingClass(null);
            setIsFormOpen(true);
          }}
          className="lg:hidden fixed bottom-24 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-xl flex items-center justify-center z-40 active:scale-90 transition-transform"
        >
          <Plus size={28} />
        </button>
      )}
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col lg:w-14 lg:h-14 items-center justify-center rounded-2xl transition-all gap-1 group relative",
        active ? "bg-blue-50 text-blue-600 shadow-sm" : "text-slate-400 hover:bg-slate-50 hover:text-slate-600"
      )}
    >
      {icon}
      <span className="text-[10px] font-bold lg:hidden">{label}</span>
      {active && <motion.div layoutId="nav-active" className="hidden lg:block absolute -left-0 w-1 h-8 bg-blue-600 rounded-r-full" />}
      <div className="hidden lg:group-hover:block absolute left-full ml-4 px-2 py-1 bg-slate-800 text-white text-xs rounded whitespace-nowrap z-50">
        {label}
      </div>
    </button>
  );
}
